package jp.co.chooyan.tcpdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    private SimpleTcpServer server;
    private TextView mainText;
    private EditText userInput;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View parent = getLayoutInflater().inflate(R.layout.activity_main, null);
        mainText = parent.findViewById(R.id.text_main);
        userInput = parent.findViewById(R.id.user_input);
        sendButton = parent.findViewById(R.id.send_button);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputText = userInput.getText().toString();
                if (server != null) {
                    server.output(inputText);
                }
            }
        });
        setContentView(parent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        server = new SimpleTcpServer(new SimpleTcpServer.TcpConnectionListener() {
            @Override
            public void onReceive(final byte[] data) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mainText.setText(new String(data));
                    }
                });
            }
        }, 20000);
        server.start();
    }
}
